const { TwitterApi } = require('twitter-api-v2');
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const cors = require('cors');

const app = express();
var corsOptions = {
  // origin: 'localhost:3000',
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
}
app.use(express.static('public'));
app.use(cors(corsOptions));
app.use(bodyParser.json());
app.get('/', function (req, res) {
  res.sendFile(path.join(__dirname, '/index.html'));
});
app.get('/script.js', function (req, res) {
  res.setHeader('Content-Type', 'text/javascript');
  res.sendFile(path.join(__dirname, '/script.js'));
});
app.post('/post-tweet', async (req, res) => {

  try {
    let apk, aps, act, acs;
    switch (req.body.acc) {
      case '1': apk = "lmaISdvBdGMS88HjeDYjqJftk"; aps = "cKqoREkTvbkKkok31OBfQeIY19ZWITi4wdpuj5WEOIViYVeToY"; 
      act = "1712444720645898240-MrYOkyyaclYDCrlPUjMQgzjJtoLSW3"; acs = "0hGyDIHJh2eUuRhuxkAkBQdvftk2yui50gA34UxYCP365"; break;
      default: apk = "YqvuFKUYjzcq9upz6BGgcsMAq"; aps = "OCb5CVPlZdDTw4TCt9aW2RFTuKqpvLXs5n7jLs85EuRuyYKVDg"; 
      act = "1710256107455700992-PrfntJF5aBLSO45ufYs3zFyngEUMpc"; acs = "xD9kpr1gymRyB3vtd6JV8TOAyXXg9TWA9K0kYlfMyLaFU"; break;
    }

    const client = new TwitterApi({
      appKey: apk,
      appSecret: aps,
      accessToken: act,
      accessSecret: acs,
    }
    );
    // Read+Write level
    const rwClient = client.readWrite;// const roClient = client.readOnly;
    // mediaIds is a string[], can be given to .tweet
    const { data: createdTweet } = await client.v2.tweet({
      text: req.body.longURL,
    });
    await client.v2.deleteTweet(createdTweet.id);

    res.json({ tco_url: createdTweet.text });

  } catch (error) {
    console.error('Error posting tweet:', error);
    res.status(500).json({ error: 'Failed to post tweet' });
  }
});
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});