document.getElementById('shortenButton').addEventListener('click', () => {
    const urlInput = document.getElementById('urlInput');
    const longURL = urlInput.value.trim();

    if (longURL) {
        shortenURLViaTwitter(longURL);
    } else {
        alert('Please enter a valid URL');
    }
});
document.getElementById('fetchTweetsButton').addEventListener('click', () => {
    fetchTweets();
});

document.getElementById('deleteTweetButton').addEventListener('click', () => {
    deleteLastTweet();
});
async function shortenURLViaTwitter(longURL) {
    const resultDiv = document.getElementById('result');
    resultDiv.textContent = 'Posting tweet...';
    const acct = document.getElementById('acc').value.trim();

    try {
        const response = await fetch('/post-tweet', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ longURL: longURL, acc:acct }),
        });

        const data = await response.json();
        if (data.tco_url) {
            resultDiv.innerHTML = `Shortened URL: <a href="${data.tco_url}" target="_blank">${data.tco_url}</a>`;
        } else {
            resultDiv.textContent = 'Failed to shorten URL.';
        }
    } catch (error) {
        console.error('Error posting tweet:', error);
        resultDiv.textContent = 'Error posting tweet : '+ error;
    }
}

async function fetchTweets() {
    const resultDiv = document.getElementById('result');
    resultDiv.textContent = 'Fetching tweets...';

    try {
        const response = await fetch('/fetch-tweets');

        const data = await response.json();
        if (data.tweets) {
            resultDiv.innerHTML = data.tweets.map(tweet => `<p>${tweet.text} (ID: ${tweet.id_str})</p>`).join('');
        } else {
            resultDiv.textContent = 'Failed to fetch tweets.';
        }
    } catch (error) {
        console.error('Error fetching tweets:', error);
        resultDiv.textContent = 'Error fetching tweets.';
    }
}

async function deleteLastTweet() {
    const resultDiv = document.getElementById('result');
    resultDiv.textContent = 'Deleting last tweet...';

    try {
        const response = await fetch('/delete-last-tweet', {
            method: 'DELETE',
        });

        const data = await response.json();
        if (data.deleted) {
            resultDiv.textContent = 'Last tweet deleted successfully.';
        } else {
            resultDiv.textContent = 'Failed to delete last tweet.';
        }
    } catch (error) {
        console.error('Error deleting tweet:', error);
        resultDiv.textContent = 'Error deleting tweet.';
    }
}